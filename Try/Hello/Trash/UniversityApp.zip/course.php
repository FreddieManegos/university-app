<?php 
include("includes/header.php");
include("includes/classess/Course.php");
include("includes/classess/User.php");

?>
<?php 
$data = pg_query($db, "SELECT * FROM course WHERE code = '".$_REQUEST['code']."'");
$row = pg_fetch_array($data);
?>
<div id= "profiles">
	<a href=""> <img src="<?php echo $row['adviserPicture'];?>"></a>
	<br>
</div>
<div class = "main_column column" id = "course">

	<div class = "courseInfo"> 
		<?php 
		echo "Code: ".$row['code'];
		echo "<br>Description: ".$row['description'];
		echo "<br>Section: ".$row['section'];
		echo "<br>Room:".$row['roomNo'];
		echo "<br> ".$row['startTime']."-";
		echo $row['endTime']."  ". $row['days']."<br>";
		echo "Sensei: ".$row['adviser']."<br>";
		$course_student_mod = new User($db, $_REQUEST['code']);

		if($course_student_mod->isJoined($_REQUEST['code'])){
			echo '<input type="submit" name="Unjoined" class="danger" value="Leave"><br>';
		}
		else{
			echo '<input type="submit" name="Join" class="success" value="Join"><br>';
		}
		if(isset($_POST['Join'])){
			$course_student_mod->joinCourse($_REQUEST['code']);
		}

		?>
	</div>	
</div>

</div>

</body>
</html> 