<?php 
class User {
	private $user;
	private $con;

	public function __construct($con, $user){
		$this->con = $con;
		$user_details_query = pg_query($con, "SELECT * FROM users WHERE username='$user'");
		$this->user = pg_fetch_array($user_details_query);
	}

	public function getFirstAndLastName(){
		$username = $this->user['username'];
		$query = pg_query($this->con, "SELECT first_name, last_name FROM users WHERE username = '$username'");
		$row = pg_fetch_array($query);
		return $row['first_name'] . " " . $row['last_name'] ;
	}

	public function getUsername() {
		return $this->user['username'];
	}
	public function getCourseArray(){
		$array = $this->user['course_array'];
		return $array;
	}

	public function removeCourse($courseToRemove){ 
		$logged_in = $this->user['username'];
		$query = pg_query($this->db, "SELECT course_array FROM users WHERE username='".$logged_in."'");
		$row = pg_fetch_array($query);
		$course_array = $row['course_array'];
		$new_course_array = str_replace($courseToRemove.",","",$this->user['course_array']);
		$remove_course = pg_query($this->db,"UPDATE users SET course_array = '$new_course_array' WHERE username='$logged_in'");
	}

	public function isJoined($course){
		$course_name = ",".$course.",";
		if((strstr($this->user['course_array'], $course_name) || $course == $this->user['course_array'])){
			return true;
		}else{
			return false;
		}
	}

	public function joinCourse(){

	}

	
}


 ?>