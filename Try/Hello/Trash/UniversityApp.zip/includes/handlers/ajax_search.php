<?php 
include("dbconnect.php");
include("classess/Course.php")

$query = $_POST['query'];
$userLoggedIn = $_POST['userLoggedIn'];

$course = explode(" ",$query);

$courseReturnedQuery = pg_query("SELECT * FROM course WHERE code LIKE '$course[0]%' LIMIT 8");
if($query != ""){
	while ($row = pg_fetch_array($courseReturnedQuery)) {
			//$course = new Course($db,$userLoggedIn); 
		echo "<div class= 'resultDisplay'>
		<a href='".$row['code']."' style='color: #1485BD'>";
	}

} 

?>