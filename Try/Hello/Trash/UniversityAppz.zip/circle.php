<html>
<head>
  <link rel="shortcut icon" type="image/x-icon" href="img/msuiit_tab_icon.ico">
  <link media="all" rel="stylesheet" type="text/css" href="circle.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Italiana|Amatic+SC" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <div class="container-fluid front" data-target="#inModal" data-toggle="modal">
    <p class="msuiit">M S U I I T</p>
    <hr>
    <p class="circle">Connect with your My.IIT.Circle</p>
  </div>
  <div id="inModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
     <div class="modal-content">
       <div class="modal-header" id="header">
         <button type="button" class="close" data-dismiss="modal" style="color:White">&times;</button>
         <h1 class="modal-title">My.IIT.Circle</h1>
         <h6 class="modal-title">Log in or Register</h6>
       </div>
       <div class="modal-body"><form method="POST">
        <div class="row">
         <p class="_in usein"><input class="col-lg-11" name="log_in_studentID" type="text" placeholder="Student ID" id="stdid" value=""><i class="glyphicon glyphicon-user"></i></p>
       </div>
       <div class="row">
         <p class="_in pwdin"><input class="col-lg-11" name="log_in_password" type="password" placeholder="Password" id="pwd" value=""><i class="glyphicon glyphicon-lock"></i></p>
       </div></form>
       <input type="submit" value= "Login" name="log_in_button" class="btn"></input>
       <a href="#" style="position: fixed; left: 40%; top: 76%;">Forgot Password?</a>
       <p id="signup"><a data-target="#upModal" data-toggle="modal" data-dismiss="modal"><span style="text-decoration:none;">Sign up</a> if not yet registered.</p>
       </div>
     </div>
   </div>
 </div>
</div>
<?php 
include("dbconnect.php");
if(isset($_POST["log_in_button"])){
  $studentID = pg_escape_string($_POST['log_in_studentID']);
  $_SESSION['log_in_studendID'] = $studentID;

  $password = md5($_POST['log_in_password']);

  $check_db_query = pg_query($db,"SELECT * FROM users WHERE username = '$studentID' and password = '$password'");

  $check_login_query = pg_num_rows($check_db_query);

  if($check_login_query == 1) {
    $row = pg_fetch_array($check_db_query);
    $username = $row['username'] ;

    $_SESSION['username'] = $username;
    header("Location: index.php");
    exit();
  } 
}

?> 
</body>
</html>
