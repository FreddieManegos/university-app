<?php 
class Course{
	private $course;
	private $db;

	public function __construct($db,$course){
		$this->db = $db;
		$course_details_query = pg_query("SELECT * FROM course WHERE code = '".$course."'");
		$this->course = pg_fetch_array($course_details_query);
	}

	public function getCourseCode(){
		return $this->course['code'];
	}

	public function removeStudent(){

	}

	public function addStudent(){
		
	}

}



 ?>