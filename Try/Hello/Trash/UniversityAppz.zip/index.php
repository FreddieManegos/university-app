<?php 
include("includes/header.php");
include("includes/classess/User.php");

?>
<div class = "wrapper">
	<div class="user_details column" id="profiled"> 
		<a href="<?php echo $userLoggedIn; ?>" id= "profile"> <img src="<?php echo $user['profile_pic']; ?>"></a>
		<br>
		<a href="<?php echo $userLoggedIn; ?>">
			<br>
			<strong>
				<?php 
				echo $user['first_name'] . " " . $user['last_name'];
				?>
			</strong>
		</a>
	</div>
	<div class="main_column column">
<!-- 		<form class="post_form" action="index.php" method="POST">
			<textarea name = "post_text" placeholder="Got something to say"></textarea>
			<input type="submit" id="post_button" value="POST">
			<br>
		</form> -->

		<?php 
		$user_obj = new User($db, $userLoggedIn);
		echo $user_obj->getFirstandLastName();
		echo "<br><br> All Courses in db <br>";
		$str = "<br>";
		$data = pg_query($db, "SELECT * FROM course");
		while($row = pg_fetch_array($data)){
			$code = $row['code'];
			$str .= "<a href ='course.php?code=$code'>$code</a><br>";
		}
		echo $str;
		?>

	</div>
	
	<div id = "courseList" class="courseColumn">

		<?php 
			echo "<strong>Courses in course_array:</strong> <br><br>";
			$datas = pg_query($db, "SELECT * FROM users WHERE username='$userLoggedIn'");
			$rows = pg_fetch_array($datas);
			echo $rows['course_array'];
		?>	
	</div>
	
	
</div>
</body>
</hmtl> 