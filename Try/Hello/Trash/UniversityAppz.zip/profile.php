<?php 
include("includes/header.php");
include("includes/classess/User.php");

if(isset($_GET['profile_username'])){
	$user_name = $_GET['profile_username'];
}
?>

<div class = "main_column column">
	<?php 
		$user_details = new User($db, $user_name);
		echo "<br><br><br>".$user_details->getFirstandLastName();
	 ?>
</div>

</div>

</body>
</html>