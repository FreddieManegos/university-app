<?php 
include("../../dbconnect.php");
include("../classess/User.php");
include("../classess/Course.php");

$query = $_POST['query'];
$userLoggedIn = $_POST['userLoggedIn'];

$course = explode(" ",$query); 
$name = explode(" ", $query); 


if(strpos($query, '_') !==  false){
	$usersReturnedQuery = pg_query($db, "SELECT * FROM users WHERE username LIKE '$query%' AND user_closed='no' LIMIT 8");
}else if(count($name) == 2){
	$usersReturnedQuery = pg_query($db, "SELECT * FROM users WHERE (first_name LIKE '$name[0]%' AND last_name LIKE '%$name[1]%') AND user_closed = 'no' LIMIT 8 ");

}else if(isset($query)) { 
	$usersReturnedQuery = pg_query($db, "SELECT * FROM course WHERE (code LIKE '$course[0]' OR adviser LIKE '$course[0]') LIMIT 8 ");
}

error_reporting(0);
if($query != ""){
	while($row = pg_fetch_array($usersReturnedQuery)) {
		$user = new User($db, $userLoggedIn);
		echo "<div class='resultDisplay'>
		<a href=".$row['code'].">

		<div class='liveSearchProfilePic'>
		<img src='". $row['adviserPicture'] . "'>
		</div>

		<div class='liveSearchText'>
		".$row['description']."
		<p style='margin: 0;'>". $row['adviser'] . "</p>
		</div>
		</a>
		</div>		
		<button type'button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal'>
  				Launch demo modal
		</button>";
	}
// 	while ($row = pg_fetch_array($courseReturnedQuery)) {
// 		$course = new Course($db,$userLoggedIn); 
// 		echo "<div class= 'resultDisplay'>
// 		<a href='".$row['code']."' style='color: #1485BD'>";
// }
}
?>	

<!-- Button trigger modal -->

